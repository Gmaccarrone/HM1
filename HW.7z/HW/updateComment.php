<?php
    require_once 'checkSession.php';
    if (!$id = checkSession()) {
        header("Location: login.php");
        exit;
    }
    else{
        $id = $_SESSION['id'];
        $conn = mysqli_connect("localhost","root","","tvblogdb");
        $titolo = $_POST['title'];
        $newComment = $_POST['comment'];
        $json = array('status' => 'ERROR','comment' => '');

        //controlla se esiste già un commento (tecnicamente se esiste un "valuta")
        $checkCommentQuery = "select * from valuta where utente = $id and titolo = $titolo;";
        $checkCommentRes = mysqli_query($conn, $checkCommentQuery) or die(mysqli_error($conn));
        $checkCommentRow = mysqli_fetch_assoc($checkCommentRes);

        if($checkCommentRow){
            //se trova un recensione aggiorna il voto
            $updateQuery = "update valuta set commento = '$newComment' where utente = $id and titolo = $titolo;";
            $updateRes = mysqli_query($conn, $updateQuery) or die(mysqli_error($conn));
            $json['status'] = 'OK_UPDATED';
            $json['comment'] = $newComment;
            echo json_encode($json);
        }
        else {
            //altrimenti controlla se ha effettivamente visto il titolo
            $checkVisioneQuery = "select * from visione where utente = $id and titolo = $titolo;";
            $checkVisioneRes = mysqli_query($conn, $checkVisioneQuery) or die(mysqli_error($conn));
            $checkVisioneRow = mysqli_fetch_assoc($checkVisioneRes);
            if($checkVisioneRow){
                //se l'ha visto non l'ha mai recensito, aggiungi la recensione
                $insertQuery = "insert into valuta values($id, $titolo , '$newComment',null)";
                $insertRes = mysqli_query($conn, $insertQuery) or die(mysqli_error($conn));
                $json['status'] = 'OK_INSERTED';
                $json['comment'] = $newComment;
                echo json_encode($json);
            }
            else{
                // se non l'ha nemmeno visto non lo può recensire, torna una stringa d'errore
                $json['status'] = 'ERR_NEVER_WATCHED';
                echo json_encode($json);
            }
        }
    }
?>