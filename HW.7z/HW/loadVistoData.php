<?php
require_once 'checkSession.php';
if (!$id = checkSession()) {
    header("Location: login.php");
    exit;
}
else{
    $i=0;
    $codice = $_SESSION['id'];
    $username = $_SESSION['username'];
    $conn = mysqli_connect("localhost","root","","tvblogdb");
}
    $titolo =  $_POST['title'];
    $json = array('propic' => array(),'username' => array(),'comment' => array());

    $commentQuery = "select u.propic as propic, u.username as username, v.commento as commento 
        from (utente u join valuta v on v.utente = u.codice) join titolo t on t.codice = v.titolo 
        where titolo = $titolo and v.commento is not null;";
    $commentRes  = mysqli_query($conn, $commentQuery) or die(mysqli_error($conn));

    while($commentsRow = mysqli_fetch_assoc($commentRes)) {
        $src = 'data:image/jpeg;base64,'.base64_encode($commentsRow['propic'] );

        $json['propic'][$i]=$src;
        $json['username'][$i]=$commentsRow['username'];
        $json['comment'][$i]=$commentsRow['commento'];
        
        $i++;
    }

    $personalQuery = "select visto as visto, commento as commento, voto as voto from viewsdata where utente = $codice and titolo = $titolo";
    $personalRes  = mysqli_query($conn, $personalQuery) or die(mysqli_error($conn));
    $personalRow = mysqli_fetch_assoc($personalRes); 
        $json['visto'] = $personalRow['visto'];
        $json['commento'] = $personalRow['commento'];
        $json['voto'] = $personalRow['voto'];

    $nameQuery = "SELECT nome FROM titolo where codice = $titolo;";
    $nameRes  = mysqli_query($conn, $nameQuery) or die(mysqli_error($conn));
    $nameRow = mysqli_fetch_assoc($nameRes); 
        $json['nome'] = $nameRow['nome'];
        echo json_encode($json);
?>