<?php
    
    session_start();
    $conn = mysqli_connect('localhost','root','','tvblogdb') or die(mysqli_error($conn));
    $error = '';

    if (!empty($_POST["username"]) && !empty($_POST['email']) && !empty($_POST["password"]) ){

                
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
    
        $pass = mysqli_real_escape_string($conn, $_POST['password']);
        $pass = password_hash($pass, PASSWORD_BCRYPT);
        $query = "SELECT * FROM utente WHERE username LIKE '$username' AND email like '$email';";
        $res = mysqli_query($conn, $query) or die(mysqli_error($conn)); 

        if (mysqli_num_rows($res)===1) {
            $credentials =  mysqli_fetch_assoc($res);
            if(password_verify($_POST['password'], $credentials['password'])){
            
            $_SESSION["username"] = $credentials['username'];
            $_SESSION["id"] = $credentials['codice'];
            mysqli_free_result($res);
            mysqli_close($conn);
            header("Location: home.php");
            exit;
            }
            else $error = 'Password errata';
        }
        else $error = 'Account non trovato';
        mysqli_free_result($res);
        mysqli_close($conn);
    }
?>

<html>
    <head>
    <link rel='stylesheet' href='./style/formsStyle.css'>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">

    <script src='./scripts/checkLogin.js' defer></script>

    <link rel="shortcut icon" type="image/png" href="favicon.png">
    <title>TVBlog - LogIn</title>
    </head>
    <body>
        <main>
            <section id = 'welcomePhoto'>
            </section>
            <section id = 'signupForm'>

                <h1>
                    Accedi
                    <?php
                    echo"<span class = 'mainSpan'>$error</span>";
                    ?>
                </h1>
                <form name='signup' method='post' enctype="multipart/form-data" autocomplete="off">
                    
                <div><label for='username'>Username</label></div>
                    <div><input type='text' name='username' id = 'username'></div>
                    <div><span id = 'usernameSpan'></span></div>

                    <div><label for='email'>eMail</label></div>
                    <div><input type='email' name='email' id='email'></div>
                    <div><span id = 'emailSpan'></span></div>
                    
                    <div><label for='password'>Password</label></div>
                    <div><input type='password' name='password' id = 'pass'></div>
                    <div><span id = 'passSpan'></span></div>

                    <div>
                    <label>&nbsp;<input type='submit' name='submit' id = 'submit' disabled = 'disabled'></label>
                    </div>
                    <div id ="toLogin">Non hai un account? <a href="signup.php">Iscriviti!</a></div>
                </form>
            </section>
        </main>
    </body>    
</html>