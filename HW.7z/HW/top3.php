<?php 
    require_once 'checkSession.php';
        if (!$id = checkSession()) {
            header("Location: login.php");
            exit;
        }
    else{
        $conn = mysqli_connect("localhost","root","","tvblogdb");
        $query = "select * from titData order by vievs desc;";
        $res = mysqli_query($conn, $query) or die(mysqli_error($conn));
        $json = array('title','codice');
         
        for($i=0; $i<3; $i++){
            $row = mysqli_fetch_assoc($res);
            $json['title'][$i] = $row['nome'];
            $json['codice'][$i] = $row['codice'];
        }
        echo json_encode($json);
    }
?>