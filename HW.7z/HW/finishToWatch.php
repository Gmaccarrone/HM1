<?php 
require_once 'checkSession.php';
    if (!$id = checkSession()) {
        header("Location: login.php");
        exit;
    }
    else{
        $codice = $_SESSION['id'];
        $conn = mysqli_connect("localhost","root","","tvblogdb");
    }
    //recupera dati post
    $titleID = $_POST['titleID'];
    $query = "select * from visione where titolo = $titleID and utente = $codice;";
    $res = mysqli_query($conn, $query) or die(mysqli_error($conn));
    $row = mysqli_fetch_assoc($res);
    if($row && $row['guardando'] == false){
        $json['status'] = 'NOT_WATCHING';
        echo json_encode($json);
    } 
    else if($row && $row['guardando'] == true){
        $updateQuery = "update visione set n_visto = n_visto + 1, guardando = 0 where utente = $codice and titolo = $titleID;";
        $uRes = mysqli_query($conn, $updateQuery) or die(mysqli_error($conn));
        $json['status'] = 'OK_UPDATED';
        echo json_encode($json);
    } 
    else{ //aggiungi un valuta;
        $insertQuery ="insert into visione values(0,$codice,$titleID,current_date,1,0);";
        $iRes = mysqli_query($conn, $insertQuery) or die(mysqli_error($conn));
        $json['status'] = 'OK_INSERTED';
        echo json_encode($json);
    }
?>