<?php 
require_once 'checkSession.php';
    if (!$id = checkSession()) {
        header("Location: login.php");
        exit;
    }
    else{
        $codice = $_SESSION['id'];
        $conn = mysqli_connect("localhost","root","","tvblogdb");
    }
    //recupera dati post
    $titleID = $_POST['titleID'];

    $query = "select * from titdata where codice = $titleID;";
    $res = mysqli_query($conn, $query) or die(mysqli_error($conn));
    if($res){
        $wRow = mysqli_fetch_assoc($res);
        $sQuery = "select n_visto from visione where titolo = $titleID and utente = $codice;";

        $sRes = mysqli_query($conn, $sQuery) or die(mysqli_error($conn));
        $sRow = mysqli_fetch_assoc($sRes);
        if(!$sRow) $sRow = array('n_visto' => '0');

        $uploaderID = $wRow['uploader'];
        $picQuery = "select propic from utente where codice = $uploaderID;";
        $picRes = mysqli_query($conn, $picQuery) or die(mysqli_error($conn));
        $picRow = mysqli_fetch_assoc($picRes);

    $json = array  ('codice' => $wRow['codice'],
                    'nome' => $wRow['nome'],
                    'database' =>$wRow['db'],
                    'uploader' =>$wRow['uploader'],
                    'globalRate' => $wRow['punteggio'],
                    'views' => $wRow['vievs'],
                    'watchingnow' => $wRow['watching'],
                    'yourViews' => $sRow['n_visto'],
                    'propic' => 'data:image1/jpeg;base64,'.base64_encode($picRow['propic'])
                    );

    echo json_encode($json);
    } else echo json_encode(null);
?>