<head>
    <title>Tv Blog - Preferiti</title>
    <meta name="viewport" content="width=device-width, initial-scale1">
    <meta charset="utf-8">

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">

    <link href="./style/genresStyle.css" rel = "stylesheet">
    <link href="./style/genresHeaderAndFooter.css" rel = "stylesheet">

    <script src="genresDatas.js" defer></script>
    <script src="./scripts/genresScripts.js" defer></script>
    <script src='./scripts/logout.js' defer></script>
    
</head>
<body>
<div id = 'modalov' class='hidden'>
        <div id = 'lastWarningLogout' class='hidden'>
            <div id = 'warning'>Sicuro di voler eseguire il logout?</div>
            <div id="logoutMenu">
                <a class="link" id="abort">annulla</a>
                <a class="link" href="logout.php" id="cLogout">logout</a>
            </div>
        </div>
    </div>
   
    <header>
        <div id="top">
            <img src="./images/tvblogo.png" id = 'logo'>
            <nav>
                <a class="link" href="home.php" id="home">Home</a>
                <a class="link" href="cerca.php" id="cerca">Cerca</a>
                <a class="link" href="generi.php" id="generi">Generi</a>
                <a class="link" href="visto.php" id="visto">Visto</a>
                <a class="link" id="logout">logout</a>
            </nav>
            <nav id = "box-menu">
                <h3 id="menu-line"> </h3>
                <h3 id="menu-line"> </h3>
                <h3 id="menu-line"> </h3>
            </nav>
        </div>
    </header>
        <p id = "pref" class="hidden">I tuoi Preferiti:</p>
        <section id="gen-pref" class="hidden">
             <!--qui verranno messi i generi preferiti-->
        </section>
        <nav id="gen-bar">  
            <p>Generi:</p>
            <box id="search-box">
                <img src="https://www.materialui.co/materialIcons/action/search_white_192x192.png" id="search-img">
                <input placeholder="Cerca" class="hidden"></input>
            </box>
        </nav>
        <section id="gen-grid">
            <!--qui verranno messi i generi-->
        </section>
    <footer>
        <txt-footer>Powered by Giuseppe Maccarrone - O46001814</txt-footer><br>
        <txt-footer id="uni">Università degli studi di catania - corso di web programming</txt-footer>
    </footer>
</body>