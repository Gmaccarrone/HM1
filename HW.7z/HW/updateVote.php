<?php
    require_once 'checkSession.php';
    if (!$id = checkSession()) {
        header("Location: login.php");
        exit;
    }
    else{
        $id = $_SESSION['id'];
        $conn = mysqli_connect("localhost","root","","tvblogdb");
        $titolo = $_POST['title'];
        $newVote = $_POST['rate'];
        $json = array('status' => 'ERROR');

        //controlla se esiste già un voto (tecnicamente se esiste un "valuta")
        $checkVoteQuery = "select * from valuta where utente = $id and titolo = $titolo;";
        $checkVoteRes = mysqli_query($conn, $checkVoteQuery) or die(mysqli_error($conn));
        $checkVoteRow = mysqli_fetch_assoc($checkVoteRes);

        if($checkVoteRow){
            //se trova un recensione aggiorna il voto
            $updateQuery = "update valuta set voto = $newVote where utente = $id and titolo = $titolo;";
            $updateRes = mysqli_query($conn, $updateQuery) or die(mysqli_error($conn));
            $json['status'] = 'OK_UPDATED';
            echo json_encode($json);
        }
        else {
            //altrimenti controlla se ha effettivamente visto il titolo
            $checkVisioneQuery = "select * from visione where utente = $id and titolo = $titolo;";
            $checkVisioneRes = mysqli_query($conn, $checkVisioneQuery) or die(mysqli_error($conn));
            $checkVisioneRow = mysqli_fetch_assoc($checkVisioneRes);
            if($checkVisioneRow){
                //se l'ha visto non l'ha mai recensito, aggiungi la recensione
                $insertQuery = "insert into valuta values($id, $titolo ,null,$newVote)";
                $insertRes = mysqli_query($conn, $insertQuery) or die(mysqli_error($conn));
                $json['status'] = 'OK_INSERTED';
                echo json_encode($json);
            }
            else{
                // se non l'ha nemmeno visto non lo può recensire, torna una stringa d'errore
                $json['status'] = 'ERR_NEVER_WATCHED';
                echo json_encode($json);
            }
        }
    }
?>