
//CARICA TUTTI I DATI DI UN DETERMINATO TITOLO
function onLVDjson(json){

    console.log(json);
    const saw = document.querySelector('#saw');
    const commentArea = document.querySelector('#commentArea');
    commentArea.value = '';
    if(json.commento === null) json.commento = 'Scrivi un commento . . .';
    commentArea.placeholder = json.commento;
    saw.textContent = json.visto;
    title.textContent = json.nome;
    


    for(i = 0; i<json.voto; i++){
        const star = document.querySelector('#s'+(i+1));
        star.src = "./images/star.png";
        star.removeEventListener("mouseout",starNormal);
        star.removeEventListener("mouseover",starHover);
    }
    for(i = parseInt(json.voto) ; i<5; i++){
        const star = document.querySelector('#s'+(i+1));
        star.removeEventListener("mouseout",starNormal);
        star.removeEventListener("mouseover",starHover);
        star.addEventListener("mouseout",StarNormalUpdated);
        star.addEventListener("mouseover",StarHoverUpdated);
    }
    // carica i commenti
    const commentsGrid = document.querySelector('#commentsGrid');
    commentsGrid.innerHTML = '';
    for(i=0; i<json.comment.length; i++){
        const div = document.createElement('div');
        const pic = document.createElement('img');
        const dt = document.createElement('div');
        const usernm = document.createElement('div');
        const cmm = document.createElement('div');
        
        div.id='otherComment';
        pic.id='pic';
        dt.id='commentBox';
        usernm.id='writer';
        cmm.id ='cmm';

        pic.src=json.propic[i];
        usernm.textContent = json.username[i];
        cmm.textContent = json.comment[i]; 

        dt.appendChild(usernm);
        dt.appendChild(cmm);

        div.appendChild(pic);
        div.appendChild(dt);

        commentsGrid.appendChild(div);
    }
}
function loadData(id){
    title.id = id; 
    var infoData = new FormData();
    infoData.append('title',id);
    fetch("loadVistoData.php",{method: 'post', body: infoData}).then(onResponse).then(onLVDjson);
}
//AGGIORNA VOTO
function onUpRateJson(json){
    console.log(json);
    loadData(title.id);
}
//FUNZIONI STELLE
function StarNormalUpdated(event){
    for(i=start; i<event.currentTarget.id[1];i++){
        star[i].src = "./images/emtyStar.png";
        star[i].addEventListener('mouseover',StarHoverUpdated);
        star[i].removeEventListener('mouseout',StarNormalUpdated);
        
    }
}
function StarHoverUpdated(event){
    for (i=0;i<star.length;i++){
        if(star[i].src === "http://localhost/HW/images/emtyStar.png"){ 
            start = i;
            break;
        }
    }
    for(i=start; i<event.currentTarget.id[1];i++){
        star[i].src = "./images/star.png";
        star[i].addEventListener('mouseout',StarNormalUpdated)
    }
}
function updateRate(event){//invia voto
    

    const rate = event.currentTarget.id[1];
    var voteData = new FormData();
    voteData.append('rate',rate);
    voteData.append('title',title.id);
    fetch("updateVote.php",{method: 'post', body: voteData}).then(onResponse).then(onUpRateJson);
    
    //aggiorna stelle
    for(i=0; i<rate; i++){
        star[i].src="./images/star.png";
        star[i].removeEventListener('mouseout',starNormal);
        star[i].removeEventListener('mouseover',starHover);
        star[i].removeEventListener('mouseover',StarHoverUpdated);
        star[i].removeEventListener('mouseout',StarNormalUpdated);
    }
    for(i=rate; i<5; i++){
        star[i].src="./images/emtyStar.png";
        star[i].removeEventListener('mouseout',starNormal);
        star[i].removeEventListener('mouseover',starHover); 
        star[i].addEventListener('mouseover',StarHoverUpdated)
    }
}
function starNormal(event){
    for(i=0; i<event.currentTarget.id[1]; i++){
        star[i].src="./images/emtyStar.png";
    }
    event.currentTarget.addEventListener('mouseover',starHover)  
}
function starHover(event){
    for(i=0; i<event.currentTarget.id[1]; i++){
        star[i].src="./images/star.png";
    }
    event.currentTarget.addEventListener('mouseout',starNormal)
}
//mostra/chiudi info
function remInfo(event){
    const overl = document.querySelector("#modalovTitle");
    const Tinfo = document.querySelector("#TitleInfo");

    Tinfo.classList.add("hidden");
    overl.classList.add("hidden");
}

function moreInfo(event){
    const overl = document.querySelector("#modalovTitle");
    const Tinfo = document.querySelector("#TitleInfo");

    Tinfo.classList.remove("hidden");
    overl.classList.remove("hidden");
    loadData(event.currentTarget.id);
}
// inc/dec volte visto
function onIncJson(json){
    loadData(title.id);
}
function incSaw(event){
    var infoData = new FormData();
    infoData.append('titleID', title.id);
    fetch("addSaw.php",{method: 'post', body: infoData}).then(onResponse).then(onIncJson);
    
}
function decSaw(event){
    var infoData = new FormData();
    infoData.append('titleID', title.id);
    fetch("remSaw.php",{method: 'post', body: infoData}).then(onResponse).then(onIncJson);
}

// MOSTRA/NASCONDI COMMENTO
function hideComment(event){
    const div = document.querySelector('#comment');
    const text = document.querySelector('#commentArea');
    const submit = document.querySelector('#submit');

    div.classList.add('hidden');
    text.classList.add('hidden');
    submit.classList.add('hidden');
    writeButton.addEventListener('click', showComment);
    writeButton.removeEventListener('click', hideComment);

}
function showComment(event){
    const div = document.querySelector('#comment');
    const text = document.querySelector('#commentArea');
    const submit = document.querySelector('#submit');

    div.classList.remove('hidden');
    text.classList.remove('hidden');
    submit.classList.remove('hidden');
    writeButton.addEventListener('click', hideComment);
    writeButton.removeEventListener('click', showComment);
}
// INVIA COMMENTO
function sendComment(event){
    const comment = document.querySelector('#commentArea');
    if(comment.value.length>0){
        var commentData = new FormData();
        commentData.append('comment', comment.value);
        commentData.append('title',title.id);
        fetch('updateComment.php',{method: 'post', body: commentData}).then(onResponse).then(onUpRateJson);
    }
}
//carica dati principali
function onLoadJson(json){
    console.log(json);
    const grid = document.querySelector("#resultGrid");
    for(i = 0; i<json.codes.length; i++){
        const div = document.createElement('div');
        div.textContent = json.titles[i];
        div.id = json.codes[i];
        div.classList.add('button');
        div.addEventListener('click',moreInfo);
        grid.appendChild(div);
    }
}

function onResponse(response){
    if (!response.ok) {return null};
    return response.json();
}
console.log("updated 12");
const title = document.querySelector('.titleName');
fetch("loadTitles.php").then(onResponse).then(onLoadJson);


const star = document.querySelectorAll('.star');
const abTitle = document.querySelector("#abortTitle");
const inc = document.querySelector("#incButton");
const dec = document.querySelector("#decButton");
const writeButton = document.querySelector('#writeComment');
const submitButton = document.querySelector('#submit');

writeButton.addEventListener('click',showComment);
inc.addEventListener('click',incSaw);
dec.addEventListener('click',decSaw);
abTitle.addEventListener('click',remInfo);
submitButton.addEventListener('click',sendComment);

//aggiunge eventi per le stelle
for(i = 0; i<star.length; i++){
    star[i].addEventListener('mouseover',starHover);
    star[i].addEventListener('click',updateRate);
}