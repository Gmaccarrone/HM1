function biggerDiv(event){
    for(i=0; i<DATA_LIST.length; i++){
        if(event.currentTarget.querySelector("txt").textContent === DATA_LIST[i].desc){
            var str = '#'+DATA_LIST[i].titolo
        }
    }
    const div = document.querySelectorAll(str);
    const overlay = document.querySelectorAll(str + ' #div-overlay');
    const img = document.querySelectorAll(str + ' #background');
    const box = document.querySelectorAll(str + ' #box');


    if(event.currentTarget.classList.contains('genGrid') && div.length<3){
        if(div[0].classList.contains('big')===false){
            div[0].classList.add('big');
            overlay[0].classList.add('big');
            img[0].classList.add('big');
            box[0].classList.add('big');
            box[0].querySelector('.detTriangle').classList.add('big');
        }
        else{
            div[0].classList.remove('big');
            overlay[0].classList.remove('big');
            img[0].classList.remove('big');
            box[0].classList.remove('big');
            box[0].querySelector('.detTriangle').classList.remove('big');
        }    
    }
    else if(event.currentTarget.classList.contains('genGrid') && div.length === 3){
        if(div[2].classList.contains('big')===false){
            div[2].classList.add('big');
            overlay[1].classList.add('big');
            img[1].classList.add('big');
            box[1].classList.add('big');
            box[1].querySelector('.detTriangle').classList.add('big');
        }
        else{
            div[2].classList.remove('big');
            overlay[1].classList.remove('big');
            img[1].classList.remove('big');
            box[1].classList.remove('big');
            box[1].querySelector('.detTriangle').classList.remove('big');
        }
    }
    else{
        if(div[0].classList.contains('big')===false){
            div[0].classList.add('big');
            overlay[0].classList.add('big');
            img[0].classList.add('big');
            box[0].classList.add('big');
            box[0].querySelector('.detTriangle').classList.add('big');
        }
        else{
            div[0].classList.remove('big');
            overlay[0].classList.remove('big');
            img[0].classList.remove('big');
            box[0].classList.remove('big');
            box[0].querySelector('.detTriangle').classList.remove('big');
        }
    }    
}

function onJson(json){
    console.log(json);
}

function onLJson(json){
    if(json === "NOT_FOUND"){
        refreshGen();
        return
    }

    console.log(json);
    for(i = 0; i<json.length; i++){
        if(json[i].status === "1"){
            DATA_LIST[i].status = 'selected';
        }
        else DATA_LIST[i].status = 'unselected';
    }
    updateSections();
}

function onResponse(response) {
    if (!response.ok) {return null};
        return response.json();
}

function updateSections(){
    var success = false;
    prefGrid.innerHTML = '';

    var infoData = new FormData();

    for(i = 0; i<DATA_LIST.length; i++){
        if(DATA_LIST[i].status === 'selected'){
            prefGrid.appendChild(createDiv(DATA_LIST[i].img, DATA_LIST[i].titolo, DATA_LIST[i].desc, DATA_LIST[i].status, "prefGrid"));
            success = true;
        }
        infoData.append(('status'+i),DATA_LIST[i].status);
        //console.log(DATA_LIST[i].titolo,DATA_LIST[i].status);
    }
    if(success === true){
        const p = document.querySelector('#pref');
        prefGrid.classList.remove('hidden');
        p.classList.remove('hidden');
    }
    else{
        const p = document.querySelector('#pref');
        p.classList.add('hidden');
    }
    if(searchBuff.length === 0) {refreshGen();}

    //for (var value of infoData.values()) {
    //    console.log(value);
    // }
    fetch("updateGenres.php",{method: 'post',body: infoData}).then(onResponse).then(onJson);
}

function select(event){
    for(i = 0; i < DATA_LIST.length; i++){
        if(event.currentTarget.id === DATA_LIST[i].titolo){
            delete DATA_LIST[i].status;
            DATA_LIST[i].status = "selected";
            updateSections();
        }
    }
}

function unselect(event){
    for(i = 0; i < DATA_LIST.length; i++){
        if(event.currentTarget.id === DATA_LIST[i].titolo){
            delete DATA_LIST[i].status;
            DATA_LIST[i].status = "unselected";
            updateSections();
        }
    }
}

function showDet(event){
    const target = event.currentTarget.querySelector('txt');
    if(target.classList.contains('hidden')){
        target.classList.remove('hidden');
    }
    else{
        target.classList.add('hidden');
    }
}

function createDetailBox(hiddenText,pos){

    const box = document.createElement('box');
    box.classList.add(pos);
    box.addEventListener('click',showDet);
    
    const bar = document.createElement('bar');

    const img = document.createElement('img');
    img.classList.add("detTriangle");
    img.src = "https://www.pngkit.com/png/full/44-440751_transparent-triangle-white-white-triangle-png.png";

    const button = document.createElement('b');
    button.textContent = "dettagli";

    const details = document.createElement('txt');
    details.textContent = hiddenText;
    details.classList.add("hidden");

    bar.appendChild(img);
    bar.appendChild(button);
    box.appendChild(bar);
    box.appendChild(details);
    
    return box;
}

function createDiv(img,tit,det,status,pos){
    const div = document.createElement('div');
    div.id = tit;
    div.classList.add("category");

    const image = document.createElement('img');
    image.src = img;
    image.id = 'background';
    const title = document.createElement('h1');
    title.textContent = tit;
    const overlay = document.createElement('p');
    overlay.id = "div-overlay";
    
    const details = createDetailBox(det,pos);
    details.id = "box";
    details.addEventListener('click',biggerDiv);

    if(status === "unselected" && pos === "genGrid"){
        const addButton = document.createElement('img');
        addButton.classList.add("addButton");
        addButton.id = tit;
        addButton.src = "https://cdn2.iconfinder.com/data/icons/bitsies/128/Add-512.png"
        addButton.addEventListener('click',select);
        
        div.appendChild(addButton);
    }
    else if(status === "selected" && pos === "prefGrid"){
        const remButton = document.createElement('img');
        remButton.classList.add("remButton");
        remButton.id = tit;
        remButton.src = "https://cdn3.iconfinder.com/data/icons/flat-actions-icons-9/792/Close_Icon_Dark-512.png"
        remButton.addEventListener('click',unselect);
        
        div.appendChild(remButton);
    }


    div.appendChild(image);
    div.appendChild(title);
    div.appendChild(details);
    div.appendChild(overlay);

    return div
}

function addHidden(event){
    
    const input = document.querySelector('input');
    setTimeout(() => input.classList.add('hidden'),500);
}

function removeHidden(event){
    const input = document.querySelector('input');
    setTimeout(() => input.classList.remove('hidden'),500);
    ;
    setTimeout(() => sBox.addEventListener('mouseout',addHidden),500);
}

function refreshGen(){
    genGrid.innerHTML = '';
    for(i = 0 ; i<DATA_LIST.length ; i++){
        const div = createDiv(DATA_LIST[i].img, DATA_LIST[i].titolo, DATA_LIST[i].desc, DATA_LIST[i].status, "genGrid");
        genGrid.appendChild(div);
    }
}

function filterDivs(buff){
    genGrid.innerHTML = '';
    for(i = 0 ; i<DATA_LIST.length ; i++){
        if(DATA_LIST[i].titolo.toLowerCase().includes(buff.toLowerCase())){
            const div = createDiv(DATA_LIST[i].img, DATA_LIST[i].titolo, DATA_LIST[i].desc, DATA_LIST[i].status, "genGrid");
            genGrid.appendChild(div);
        }
    }
}

function readSearchBuff(event){
    searchBuff = document.querySelector('input').value
    
    if(searchBuff.length > 0){filterDivs(searchBuff);}
    else refreshGen();
}
console.log('versione 23');
const prefGrid = document.querySelector('#gen-pref');
const genGrid = document.querySelector('#gen-grid');
const sBox = document.querySelector('#search-box');
const searchBar = document.querySelector('input');
searchBar.addEventListener('keyup',readSearchBuff);
var searchBuff = "";
sBox.addEventListener('mouseover',removeHidden);
fetch("lookForGenPreferences.php").then(onResponse).then(onLJson);
