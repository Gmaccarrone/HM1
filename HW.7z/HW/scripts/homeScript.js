//fattorizza le migliaia
function kFormatter(num) {
    return Math.abs(num) > 999 ? Math.sign(num)*((Math.abs(num)/1000).toFixed(1)) + 'k' : Math.sign(num)*Math.abs(num)
}  
//MOSTRA STATO RICHIESTA VOTO E COMMENTO
function onUpRateJson(json){
    console.log(json);
    var infoData = new FormData();
    infoData.append('titleID', document.querySelector('.titlename').id);
    fetch("loadWatchingTitlesInfo.php",{method: 'post', body: infoData}).then(onWTIResponse).then(onWTIJson);
}
//FUNZIONI STELLE
function StarNormalUpdated(event){
    for(i=start; i<event.currentTarget.id[1];i++){
        star[i].src = "./images/emtyStar.png";
        star[i].addEventListener('mouseover',StarHoverUpdated);
        star[i].removeEventListener('mouseout',StarNormalUpdated);
        
    }
}
function StarHoverUpdated(event){
    for (i=0;i<star.length;i++){
        if(star[i].src === "http://localhost/HW/images/emtyStar.png"){ 
            start = i;
            break;
        }
    }
    for(i=start; i<event.currentTarget.id[1];i++){
        star[i].src = "./images/star.png";
        star[i].addEventListener('mouseout',StarNormalUpdated)
    }
}
    //INVIA VOTO
function updateRate(event){
    const titleName = document.querySelector(".titleName");

    const rate = event.currentTarget.id[1];
    var voteData = new FormData();
    voteData.append('rate',rate);
    voteData.append('title',titleName.id);
    fetch("updateVote.php",{method: 'post', body: voteData}).then(onWTIResponse).then(onUpRateJson);
    
    //aggiorna stelle
    for(i=0; i<rate; i++){
        star[i].src="./images/star.png";
        star[i].removeEventListener('mouseout',starNormal);
        star[i].removeEventListener('mouseover',starHover);
        star[i].removeEventListener('mouseover',StarHoverUpdated);
        star[i].removeEventListener('mouseout',StarNormalUpdated);
    }
    for(i=rate; i<5; i++){
        star[i].src="./images/emtyStar.png";
        star[i].removeEventListener('mouseout',starNormal);
        star[i].removeEventListener('mouseover',starHover); 
        star[i].addEventListener('mouseover',StarHoverUpdated)
    }
}
function starNormal(event){
    for(i=0; i<event.currentTarget.id[1]; i++){
        star[i].src="./images/emtyStar.png";
    }
    event.currentTarget.addEventListener('mouseover',starHover)  
}
function starHover(event){
    for(i=0; i<event.currentTarget.id[1]; i++){
        star[i].src="./images/star.png";
    }
    event.currentTarget.addEventListener('mouseout',starNormal)
}
// CARICA DATI DEL TITOLO DAL JSON
function onWTIJson(json){
    console.log(json)
    var rate = json.globalRate;
    if(rate == null || undefined) rate = 0;
    rate  = rate.toString();
    const DBPic = document.querySelector('#DBpic');
    const name = document.querySelector('.titleName');
    const gRate = document.querySelector('#rate');
    gRate.textContent = '';
    const views = document.querySelector('#views');
    const watching = document.querySelector('#watching');
    const uploaderImg = document.querySelector('#uploaderPropic');
    const commentArea = document.querySelector('#commentArea');
    commentArea.value = '';
    if(json.comment === null) json.comment = 'Scrivi un commento . . .';
    commentArea.placeholder = json.comment;
    var vote = json.yourVote;
    if(vote == null || undefined) vote = 0;
    //inserimento immagineDB
    if(json.database === 'IMDb'){
        DBPic.src = "./images/imdbLogo.png";
    }
    else DBPic.src = "favicon.png";
    
    // inserimento immagine
    uploaderImg.src = json.propic; 
    
    // inserimento visualizzazioni totali
    views.textContent = kFormatter(json.views);

    // inserimento watching totali
    watching.textContent = kFormatter(json.watchingnow);

    //inserimento voto globale con colore dinamico
    for(i=0; i<3; i++){
        if(rate[i]===undefined && i===0)gRate.textContent += '0'
        else if(rate[i]===undefined && i===1)gRate.textContent += '.'
        else if(rate[i]===undefined && i===2)gRate.textContent += '0'
        else gRate.textContent  += rate[i];
    }
    if(gRate.textContent < 1.9){gRate.parentNode.style.borderColor = "red";} //colore dinamico
    else if(gRate.textContent < 2.9){gRate.parentNode.style.borderColor = "darkorange";}
    else if(gRate.textContent < 3.9){gRate.parentNode.style.borderColor = "gold";}
    else if(gRate.textContent < 4.6){gRate.parentNode.style.borderColor = "greenyellow";}
    else{gRate.parentNode.style.borderColor = "lime";}

    //aggiorna il nome del titolo
    name.textContent = json.nome;

    //aggiorna le stelle
    for(i=0; i<vote; i++){
        star[i].src = "./images/star.png";
        star[i].removeEventListener('mouseout',starNormal);
        star[i].removeEventListener('mouseover',starHover);
    }
    for(i=vote; i<star.length; i++){
        star[i].removeEventListener('mouseout',starNormal);
        star[i].removeEventListener('mouseover',starHover);
        star[i].addEventListener('mouseover',StarHoverUpdated);
        star[i].addEventListener('mouseout',StarNormalUpdated);
    }
}
function onWTIJsonT3(json){//versione T3
    console.log(json)

    var rate = json.globalRate;
    const DBPic = document.querySelectorAll('#DBpic');
    const name = document.querySelector('.T3titleName');
    name.id = json.codice;
    const gRate = document.querySelector('#T3rate');
    gRate.textContent = '';
    const views = document.querySelector('#T3views');
    const watching = document.querySelector('#T3watching');
    const uploaderImg = document.querySelector('#T3uploaderPropic');
    const tSaw = document.querySelector('#timesSaw');
    tSaw.textContent = json.yourViews;
    var vote = json.yourVote;
    if(vote == null || undefined) vote = 0;
    
    //inserimento immagineDB
    if(json.database === 'IMDb'){
        DBPic[1].src = "./images/imdbLogo.png";
    }
    else DBPic[1].src = "favicon.png";
    
    // inserimento immagine
    uploaderImg.src = json.propic; 
    
    // inserimento visualizzazioni totali
    views.textContent = kFormatter(json.views);

    // inserimento watching totali
    watching.textContent = kFormatter(json.watchingnow);

    //inserimento voto globale con colore dinamico
    for(i=0; i<3; i++){
        if(rate[i]===undefined && i===0)gRate.textContent += '0'
        else if(rate[i]===undefined && i===1)gRate.textContent += '.'
        else if(rate[i]===undefined && i===2)gRate.textContent += '0'
        else gRate.textContent  += rate[i];
    }

    //aggiorna il nome del titolo
    name.textContent = json.nome;
}
function onWTIResponse(response) {
    if (!response.ok) {return null};
        return response.json();
}
//MOSTRA INFO
function moreInfo(event){
    for(i=0; i<star.length; i++){
        star[i].src = "./images/emtyStar.png";
    }
    
    var infoData = new FormData();
    infoData.append('titleID',event.currentTarget.id);
    fetch("loadWatchingTitlesInfo.php",{method: 'post', body: infoData}).then(onWTIResponse).then(onWTIJson);
    const div = document.querySelector('#comment');
    const text = document.querySelector('#commentArea');
    const submit = document.querySelector('#submit');
    const titleName = document.querySelector(".titleName");
    titleName.id = event.currentTarget.id;
    const overl = document.querySelector("#modalovTitle");
    const infoBox = document.querySelector("#titleInfo");    
    overl.classList.remove('hidden');
    infoBox.classList.remove('hidden')
    div.classList.add('hidden');
    text.classList.add('hidden');
    submit.classList.add('hidden');
    writeButton.addEventListener('click', showComment);
    writeButton.removeEventListener('click', hideComment);
}
//MODALVIEW TITOLI
function abortModal(event){
    const overl = document.querySelector("#modalovTitle");
    const infoBox = document.querySelector("#titleInfo");
    const infoBoxT3 = document.querySelector("#T3TitleInfo");
    const name = document.querySelector('.titleName');
    overl.classList.add('hidden');
    infoBox.classList.add('hidden');   
    infoBoxT3.classList.add('hidden');    
    name.textContent = '';
}
//CARICA DATI PROFILO
function onWTJson(json){
    //console.log(json)
    const grid = document.querySelector('#results-grid');
    grid.innerHTML='';


    for(i = 0; i<json.titles.length; i++){
        const button = document.createElement('div');
        button.id = json.codes[i];
        button.classList.add('button');
        button.addEventListener('click',moreInfo);
        const text = document.createElement('h3');
        text.textContent = json.titles[i];
        button.appendChild(text)
        grid.appendChild(button);
        
    }
}
function onWTResponse(response) {
if (!response.ok) {return null};
    return response.json();
}
//CARICA TOP 3
function moreInfoT3(event){
    const id = event.currentTarget.querySelectorAll('h4')[1].id.substring(3);
    const pos = event.currentTarget.querySelectorAll('h4')[1].id.substring(1,2);
    //console.log('posizione:',pos,' id:',id);

    const overl = document.querySelector("#modalovTitle");
    const div = document.querySelector("#T3TitleInfo");
    const boxW = document.querySelector("#T3watchingBox");
    const boxR = document.querySelector("#T3rateBox");
    const boxV = document.querySelector("#T3viewsBox");
    const img = document.querySelector("#T3uploaderPropic");

    //modifica i colori a  secondo della posizione
    if(pos === '1'){
        div.style.borderColor = "goldenrod";
        div.style.color = "goldenrod";
        boxR.style.borderColor = "goldenrod";
        boxW.style.borderColor = "goldenrod";
        boxV.style.borderColor = "goldenrod";
        img.style.borderColor = "goldenrod";
    }
    else if(pos === '2'){
        div.style.borderColor = "silver";
        div.style.color = "silver";
        boxR.style.borderColor = "silver";
        boxW.style.borderColor = "silver";
        boxV.style.borderColor = "silver";
        img.style.borderColor = "silver";
    }
    else if(pos === '3'){
        div.style.borderColor = "rgb(202, 129, 70)"
        div.style.color = "rgb(202, 129, 70)";
        boxR.style.borderColor = "rgb(202, 129, 70)";
        boxW.style.borderColor = "rgb(202, 129, 70)";
        boxV.style.borderColor = "rgb(202, 129, 70)";
        img.style.borderColor = "rgb(202, 129, 70)";
    };
    
    var infoData = new FormData();
    infoData.append('titleID',id);
    fetch("loadTop3TitlesInfo.php",{method: 'post', body: infoData}).then(onWTIResponse).then(onWTIJsonT3);

    div.classList.remove('hidden');
    overl.classList.remove('hidden');
}
function onT3json(json){
   //console.log(json);
   var oldTop = document.querySelectorAll('.top3')
   //console.log(oldTop);

    for(i=0; i<3; i++){  
        const top = document.createElement('h4');
        const div = document.querySelector('#t'+(i+1));  
        if(oldTop.length !== 0){
            oldTop[i].parentNode.removeChild(oldTop[i]);
        }

        top.id = '#'+ (i+1) +'_'+json.codice[i];
        top.classList.add('top3');
        top.textContent = json.title[i];
        div.addEventListener('click',moreInfoT3);
        div.appendChild(top);
    }
}
// MOSTRA/NASCONDI COMMENTO
function hideComment(event){
    const div = document.querySelector('#comment');
    const text = document.querySelector('#commentArea');
    const submit = document.querySelector('#submit');

    div.classList.add('hidden');
    text.classList.add('hidden');
    submit.classList.add('hidden');
    writeButton.addEventListener('click', showComment);
    writeButton.removeEventListener('click', hideComment);

}
function showComment(event){
    const div = document.querySelector('#comment');
    const text = document.querySelector('#commentArea');
    const submit = document.querySelector('#submit');

    div.classList.remove('hidden');
    text.classList.remove('hidden');
    submit.classList.remove('hidden');
    writeButton.addEventListener('click', hideComment);
    writeButton.removeEventListener('click', showComment);
}
// INVIA COMMENTO
function sendComment(event){
    const comment = document.querySelector('#commentArea');
    if(comment.value.length>0){
        var commentData = new FormData();
        commentData.append('comment', comment.value);
        commentData.append('title',document.querySelector('.titleName').id);
        fetch('updateComment.php',{method: 'post', body: commentData}).then(onWTIResponse).then(onUpRateJson);
    }
}
//AGGIUNGI ALLA VARIABILE N_VISIONE (DB)
function refreshT3Info(json){//aggiorna le info nel sito
    console.log(json)
    const id = document.querySelector('.T3titleName').id;
    fetch("top3.php").then(onWTIResponse).then(onT3json);
    
    var infoData = new FormData();
    infoData.append('titleID',id);
    fetch("loadTop3TitlesInfo.php",{method: 'post', body: infoData}).then(onWTIResponse).then(onWTIJsonT3);
}
function addSaw(event){
    //console.log(document.querySelector('.T3titlename').id);
    var infoData = new FormData();
    infoData.append('titleID', document.querySelector('.T3titlename').id);
    fetch("addSaw.php",{method: 'post', body: infoData}).then(onWTIResponse).then(refreshT3Info);

}
//AGGIUNGI UNO A N_VISIONE IMPOSTA GUARDANDO A FALSE
function onFWTJson(json){
    console.log(json)
    const id = document.querySelector('.titlename').id;
    var infoData = new FormData();
    infoData.append('titleID',id);
    fetch("loadWatchingTitles.php").then(onWTResponse).then(onWTJson);
    console.log('uscito dal primo js');
    fetch("loadWatchingTitlesInfo.php",{method: 'post', body: infoData}).then(onWTIResponse).then(onWTIJson);
}
function finishTitle(event){
    const id = document.querySelector(".titleName").id; 
    var infoData = new FormData();
    infoData.append('titleID',id);

    fetch("finishToWatch.php",{method: 'post', body: infoData}).then(onWTResponse).then(onFWTJson);
}
//AGGIUNGI ALLA VISIONE UN TITOLO DALLA T3
function onNWTJson(json){
    console.log(json);
    fetch("loadWatchingTitles.php").then(onWTResponse).then(onWTJson);
}
function addToWatching(event){
    const id = document.querySelector(".T3TitleName").id; 
    var infoData = new FormData();
    infoData.append('titleID',id);

    fetch("addToWatching.php",{method: 'post', body: infoData}).then(onWTResponse).then(onNWTJson);
}

var start=0;
console.log('updated 61');

//aggiunge eventi per bottoni di titleInfo
const sawTitle = document.querySelector('#sawTitle');
const abortButton = document.querySelectorAll('#abortTitle');
const writeButton = document.querySelector('#writeComment');
const submitButton = document.querySelector('#submit');
const startWTitle = document.querySelector('#startWTitle');
const completeTitle = document.querySelector('#completeTitle');
submitButton.addEventListener('click',sendComment);

sawTitle.addEventListener('click',addSaw);
startWTitle.addEventListener('click',addToWatching);
completeTitle.addEventListener('click',finishTitle);

for(i = 0; i<abortButton.length; i++){
    abortButton[i].addEventListener('click',abortModal);
}
writeButton.addEventListener('click',showComment);

//aggiunge eventi per le stelle
const star = document.querySelectorAll('.star');
for(i = 0; i<star.length; i++){
    star[i].addEventListener('mouseover',starHover);
    star[i].addEventListener('click',updateRate);
}

//carica dati dal database
fetch("loadWatchingTitles.php").then(onWTResponse).then(onWTJson);
fetch("top3.php").then(onWTIResponse).then(onT3json);