function confirmLogout(event){
    const ov = document.querySelector("#modalov");
    const mod = document.querySelector("#lastWarningLogout")
    ov.classList.remove('hidden');
    mod.classList.remove('hidden');
}

function abortLogout(event){
    const ov = document.querySelector("#modalov");
    const mod = document.querySelector("#lastWarningLogout")
    ov.classList.add('hidden');
    mod.classList.add('hidden');
}



const logoutButton = document.querySelector("#logout");
const logout = document.querySelector("#cLogout");
const abort = document.querySelector("#abort");

logoutButton.addEventListener('click',confirmLogout);
abort.addEventListener('click',abortLogout);
console.log('file caricato');