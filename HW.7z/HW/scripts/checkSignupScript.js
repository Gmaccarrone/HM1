function enableSubmit(){
    var empty = true;
    const form = document.querySelectorAll('form input');
    const submit = document.querySelector('#submit');

    for(i=0; i<6; i++){
        if(form[i].value.length === 0){
            empty = true;
            break;
        }
        else empty = false;
    }

    if(update === true && empty === false){
        document.querySelector("#submit").classList.add('allowed');
        submit.disabled = false;
    }
    else{
        document.querySelector("#submit").classList.remove('allowed');
        submit.disabled = true;
    }
}

function validateUsername(event){
    const username = document.querySelector('#username');
    const span = document.querySelector('#usernameSpan');
    if(username.value.length < 5 || username.value.length === undefined){
        username.classList.add('uncorrect');
        span.textContent = "l'username deve contenere almeno 5 caratteri";
        update = false;
    }
    else{
        username.classList.remove('uncorrect');
        span.textContent = "";
        update = true;
    }
    enableSubmit();
}

function validateEmail(event) {
    const regex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    const email = document.querySelector('#email');
    const span = document.querySelector('#emailSpan')
    if(!regex.test(String(email.value).toLowerCase())){
        email.classList.add('uncorrect');
        span.textContent = "E-Mail non valida";
        update = false;
    }
    else{
        email.classList.remove('uncorrect');
        span.textContent = "";
        update = true;
    }
    enableSubmit();
}

function validatePass(event){
    const lowRegex = /^(?=.*[a-z])/;
    const uppRegex = /^(?=.*[A-Z])/;
    const numRegex = /^(?=.*[0-9])/;
    const specialRegex = /^(?=.*[!@#\$%\^&\*])/;
    const sizeRegex = /^(?=.{8,})/;

    const pass = document.querySelector('#pass');
    const span = document.querySelector('#passSpan');
    if(!lowRegex.test(String(pass.value))){
        pass.classList.add('uncorrect');
        span.textContent = "aggiungi almeno un carattere minuscolo";
        update = false;
    }
    else if(!uppRegex.test(String(pass.value))){
        pass.classList.add('uncorrect');
        span.textContent = "aggiungi almeno un carattere maiuscolo";
        update = false;
    }
    else if(!numRegex.test(String(pass.value))){
        pass.classList.add('uncorrect');
        span.textContent = "aggiungi almeno un numero";
        update = false;
    }
    else if(!specialRegex.test(String(pass.value))){
        pass.classList.add('uncorrect');
        span.textContent = "aggiungi almeno un carattere speciale";
        update = false;
    }
    else if(!sizeRegex.test(String(pass.value))){
        pass.classList.add('uncorrect');
        span.textContent = "la password deve avere almeno 8 caratteri";
        update = false;
    }
    else{
        pass.classList.remove('uncorrect');
        span.textContent = "";
        update = true;
    }
    enableSubmit();
}

function validateCPass(event){
    const cPass = document.querySelector('#cPass');
    const pass = document.querySelector('#pass');
    const cSpan = document.querySelector('#cPassSpan');

    if(cPass.value !== pass.value){
        cPass.classList.add('uncorrect');
        pass.classList.add('uncorrect');
        cSpan.textContent = "Le due E-Mail non corrispondono";
        update = false;
    }
    else{
        cPass.classList.remove('uncorrect');
        pass.classList.remove('uncorrect');
        cSpan.textContent = "";
        update = true;
    }
    enableSubmit();
}

function validateDate(event){
    const date = document.querySelector('#date');
    const dateSpan = document.querySelector('#dateSpan');

    var today = new Date();
    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    const yyyy = today.getFullYear();

    today = yyyy + '-' + mm + '-' + dd;

    if(date.value > today){
        date.classList.add('uncorrect');
        dateSpan.textContent = "Non puoi essere nato nel futuro!";
        update = false;
    }
    else if(date.value === undefined || date.value === null || date.value === ''){
        date.classList.add('uncorrect');
        dateSpan.textContent = "Non puoi non essere nato!";
        update = false;
    }
    else{
        date.classList.remove('uncorrect');
        dateSpan.textContent = "";
        update = true;
    }
    enableSubmit();
}

function validatePropic(event){
    const file = document.querySelector('#propic');
    const button = document.querySelector('#fakeInputFile');
    const fileSpan = document.querySelector('#propicSpan');

    button.textContent = file.files[0].name;
    if(file.files[0].size > 1600000){
        button.classList.add('uncorrect');
        fileSpan.textContent = "file troppo grande";
        update = false;
    }
    else{
        button.classList.remove('uncorrect');
        fileSpan.textContent = "";
        update = true;
    }
 
    enableSubmit();
}
var update = false;
document.querySelector('#email').addEventListener('blur', validateEmail);
document.querySelector('#username').addEventListener('blur', validateUsername);
document.querySelector('#pass').addEventListener('blur', validatePass);
document.querySelector('#cPass').addEventListener('blur', validateCPass);
document.querySelector('#date').addEventListener('blur', validateDate);
document.querySelector('#propic').addEventListener('change', validatePropic);