function kFormatter(num) {
  return Math.abs(num) > 999 ? Math.sign(num)*((Math.abs(num)/1000).toFixed(1)) + 'k' : Math.sign(num)*Math.abs(num)
}  
function createNotFoundImg(){
  const div = document.createElement('div');
  div.id = 'albumNotFound';

  const txt = document.createElement('a');
  txt.innerText = 'Non abbiamo trovato niente :('
  txt.id = 'nameAlbumNotFound';
  
  const img = document.createElement('img');
  img.id = "spotifyResultImgNotFound";
  img.src = 'https://www.crearecreativita.it/wp-content/uploads/2015/07/trex.gif';

  div.appendChild(txt);
  div.appendChild(img);
  return div;
}
function IMDBCreateNotFoundImg(){
  const div = document.createElement('div');
  div.id = 'IMDBNotFound';

  const txt = document.createElement('a');
  txt.innerText = 'Non abbiamo trovato niente :('
  txt.id = 'IMDBNameNotFound';
  
  const img = document.createElement('img');
  img.id = "IMDBResultImgNotFound";
  img.src = 'https://www.crearecreativita.it/wp-content/uploads/2015/07/trex.gif';

  div.appendChild(txt);
  div.appendChild(img);
  return div;
}
function showBox(){

  const box = document.querySelector('#IMDBBox');
  box.classList.remove('hidden');
  const poster = document.querySelector('#IMDBPoster');
  poster.classList.remove('hidden');
  const title = document.querySelector('#IMDBTitle');
  title.classList.remove('hidden');
  const logo = document.querySelector('#IMDBLogo');
  logo.classList.remove('hidden');
  const rate = document.querySelector('#IMDBRate');
  rate.classList.remove('hidden');
  const rateTxt = document.querySelector('#IMDBRateTxt');
  rateTxt.classList.remove('hidden');
  const resTitle = document.querySelector('#IMDBResultTitle');
  resTitle.classList.remove('hidden');
  const info = document.querySelector('#IMDBInfo');
  info.classList.remove('hidden');
  
  const det = document.querySelector('#IMDBDetails');
  det.classList.remove('hidden');
}
function hideWaitingBox(){
  const titles = document.querySelectorAll('.waitingTitle');
  const div = document.querySelector('#waitingDiv');
  const img = document.querySelector('#waitingImg');
  img.classList.add('hidden');
  div.classList.add('hidden');
  for(i = 0; i < titles.length; i++){
    console.log(titles[i]);
    titles[i].classList.add('hidden');}
}
function IMDBNotFound(){
  hideWaitingBox();
  const notFound = document.querySelectorAll('#IMDBNotFound');
  console.log(notFound);
  if(notFound.length > 0){
    for(i = 0; i<notFound.length; i++)
    notFound[i].innerHTML = '';
  }
  const box = document.querySelector('#IMDBBox');
  box.classList.remove('hidden');
  const title = document.querySelector('#IMDBTitle');
  title.classList.remove('hidden');
  const logo = document.querySelector('#IMDBLogo');
  logo.classList.remove('hidden');


  const poster = document.querySelector('#IMDBPoster');
  poster.classList.add('hidden');
  const rate = document.querySelector('#IMDBRate');
  rate.classList.add('hidden');
  const rateTxt = document.querySelector('#IMDBRateTxt');
  rateTxt.classList.add('hidden');

  const det = document.querySelector('#IMDBDetails');
  det.classList.add('hidden');
  const resTitle = document.querySelector('#IMDBResultTitle');
  resTitle.classList.add('hidden');
  const info = document.querySelector('#IMDBInfo');
  info.classList.add('hidden');

  const container = document.querySelector('#IMDBResult');
  
  container.appendChild(IMDBCreateNotFoundImg());  

}
function onDetJson(json)
{
  console.log(json);
  hideWaitingBox();
  showBox();
  const notFound = document.querySelectorAll('#IMDBNotFound');
  console.log(notFound);
  if(notFound.length > 0){
    for(i = 0; i<notFound.length; i++)
    notFound[i].innerHTML = '';
  }


  const plot = document.querySelector('#IMDBPlot');
  const tit = document.querySelector('#IMDBResultTitle');;
  const img = document.querySelector('#IMDBPoster');
  const type = document.querySelector('#IMDBType');
  const gen = document.querySelector('#IMDBGenres');
  const date = document.querySelector('#IMDBdate');
  const rate = document.querySelector('#IMDBRate');

  img.src = json.title.image.url;
  tit.textContent = json.title.title;
  rate.textContent = json.ratings.rating;
  gen.textContent = "Genere: ";
  for(i = 0; i<json.genres.length; i++)
  gen.textContent += json.genres[i]+" ";
  type.textContent = "Tipo: " +json.title['titleType'];
  date.textContent = "Data: " + json.releaseDate;

  if(json.plotSummary !== undefined) {
    plot.textContent = json.plotSummary.text
  }
  else {  
    plot.textContent = json.plotOutline.text 
  }

}
function onDetResponse(response)
{
  return response.json();
}
function onIMDBJson(json){
  //ottenuto l'id del primo risultato facciamo un'altra query per avere più dettagli

  fetch("https://imdb8.p.rapidapi.com/title/get-overview-details?tconst="+json.d[0].id+"&currentCountry=IT", {
	  "method": "GET",
	  "headers": {
		  "x-rapidapi-key": "44bcd0ada3mshce3431aa446ca15p1b0349jsne61e14cb45e7",
		  "x-rapidapi-host": "imdb8.p.rapidapi.com"
	  }
  }).then(onDetResponse).then(onDetJson).catch(IMDBNotFound);
}
function onIMDBResponse(response)
{
  return response.json();
}
// aggiunge risultati TVB
function removeNull(json){
  if(json.visto === null || json.visto === undefined){json.visto = 0}
  if(json.views === null || json.views === undefined){json.views = 0}
  if(json.watchingnow === null || json.watchingnow === undefined){json.watchingnow = 0}
  if(json.globalRate === null || json.globalRate === undefined){json.globalRate = '0.0'}

  //console.log(json);
}
function onTVBjson(json){

  removeNull(json);

  //console.log(json);
  const name = document.querySelector(".TvbName");
  const rate = document.querySelector("#TvbRateData");
  const views = document.querySelector('#TvbViewsData');
  const watch = document.querySelector('#TvbwatchingData');
  const dbImg = document.querySelector('#DBimg');
  const upImg = document.querySelector('#UPimg');
  const saw = document.querySelector('#saw');

  saw.textContent = json.visto;
  upImg.src = json.propic;
  if(json.database === "IMDb") dbImg.src = "./images/imdbLogo.png";
  else dbImg.src = "favicon.png";
  watch.textContent = kFormatter(json.watchingnow);
  views.textContent = kFormatter(json.views);
  rate.textContent = json.globalRate.substring(0,3);
  name.textContent = json.nome;
  name.id = json.codice;
  
  
  const TVBResult = document.querySelector('#TVBResult');
  TVBResult.classList.remove('hidden');
  const TVBdata = document.querySelector('#TVBMainData');
  TVBdata.classList.remove('hidden');
  const mainTVBinfo = document.querySelector('#mainTVBinfo');
  mainTVBinfo.classList.remove('hidden');

}
function dontShow(){
  
  const TVBResult = document.querySelector('#TVBResult');
  TVBResult.classList.add('hidden');
  const TVBdata = document.querySelector('#TVBMainData');
  TVBdata.classList.add('hidden');
  const mainTVBinfo = document.querySelector('#mainTVBinfo');
  mainTVBinfo.classList.add('hidden');
}
function search(event){
    event.preventDefault();
    const title = document.querySelector("#query");
    const titleURI = encodeURIComponent(title.value);
    var infoData = new FormData();
    infoData.append('titleName',title.value);

  //richiesta IMDB per trovare l'id di un titolo secondo la nostra ricerca
  
  fetch("https://imdb8.p.rapidapi.com/auto-complete?q="+titleURI, {
	"method": "GET",
	"headers": {
		"x-rapidapi-key": "44bcd0ada3mshce3431aa446ca15p1b0349jsne61e14cb45e7",
		"x-rapidapi-host": "imdb8.p.rapidapi.com"
	  }
  }).then(onIMDBResponse).then(onIMDBJson).catch(IMDBNotFound);
  fetch("searchTitleByName.php",{method: 'post', body: infoData}).then(onDetResponse).then(onTVBjson).catch(dontShow);
  
}
//AGGIUNGI AL DATABASE IL RISULTATO DELLA RICERCA IMDB
function onAddToDBjson(json){
  console.log(json);
}
function IMDBaddToDB(event){
  const titleName = document.querySelector('#IMDBResultTitle').textContent;
  var type = document.querySelector('#IMDBType').textContent.substring(6);
  const db = 'IMDb';

  var infoData = new FormData();
  if(type === 'movie') type = 'film';
  else if(type === 'tvSeries') type = 'serie tv'; 

  infoData.append('titleName', titleName);
  infoData.append('db', db);
  infoData.append('type', type);

  fetch("addToDB.php",{method: 'post',body: infoData}).then(onIMDBResponse).then(onAddToDBjson);
}

// INC/DEC n_visto
function onIncJson(json){
  console.log(json);
  var infoData = new FormData();
  const id = document.querySelector(".TvbName").id;
  infoData.append('titleName',id);
  fetch("refreshTVBresultData.php",{method: 'post', body: infoData}).then(onDetResponse).then(onTVBjson);
}
function incSaw(event){
  const id = document.querySelector(".TvbName").id;
  var infoData = new FormData();
  infoData.append('titleID', id);
  fetch("addSaw.php",{method: 'post', body: infoData}).then(onDetResponse).then(onIncJson);
  
}
function decSaw(event){
  const id = document.querySelector(".TvbName").id;
  var infoData = new FormData();
  infoData.append('titleID', id);
  fetch("remSaw.php",{method: 'post', body: infoData}).then(onDetResponse).then(onIncJson);
}
// aggiungi a watching
function addWatching(event){
  const id = document.querySelector(".TvbName").id; 
    var infoData = new FormData();
    infoData.append('titleID',id);

    fetch("addToWatching.php",{method: 'post', body: infoData}).then(onDetResponse).then(onIncJson);
}


console.log('update 12');
const incButton = document.querySelector('#incButton');
const decButton = document.querySelector('#decButton');
const watchingButton = document.querySelector('#wButton');
const addToDBButton = document.querySelector('#IMDBAddButton');
const form = document.querySelector("#searchBar");

watchingButton.addEventListener('click',addWatching);
incButton.addEventListener('click',incSaw);
decButton.addEventListener('click',decSaw);
addToDBButton.addEventListener('click',IMDBaddToDB);
form.addEventListener('submit', search);