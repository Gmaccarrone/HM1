function enableSubmit(){
    var empty = true;
    const form = document.querySelectorAll('form input');
    const submit = document.querySelector('#submit');

    for(i=0; i<3; i++){
        console.log(form[i].value.length);
        if(form[i].value.length === 0){
            empty = true;
            break;
        }
        else empty = false;
    }

    if(update === true && empty === false){
        document.querySelector("#submit").classList.add('allowed');
        submit.disabled = false;
    }
    else{
        document.querySelector("#submit").classList.remove('allowed');
        submit.disabled = true;
    }
}

function validateUsername(event){
    const username = document.querySelector('#username');
    const span = document.querySelector('#usernameSpan');
    if(username.value.length < 5 || username.value.length === undefined){
        username.classList.add('uncorrect');
        span.textContent = "l'username deve contenere almeno 5 caratteri";
        update = false;
    }
    else{
        username.classList.remove('uncorrect');
        span.textContent = "";
        update = true;
    }
    enableSubmit();
}

function validateEmail(event) {
    const regex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    const email = document.querySelector('#email');
    const span = document.querySelector('#emailSpan')
    if(!regex.test(String(email.value).toLowerCase())){
        email.classList.add('uncorrect');
        span.textContent = "E-Mail non valida";
        update = false;
    }
    else{
        email.classList.remove('uncorrect');
        span.textContent = "";
        update = true;
    }
    enableSubmit();
}


function validatePass(event){
    /*const lowRegex = /^(?=.*[a-z])/;
    const uppRegex = /^(?=.*[A-Z])/;
    const numRegex = /^(?=.*[0-9])/;
    const specialRegex = /^(?=.*[!@#\$%\^&\*])/;
    const sizeRegex = /^(?=.{8,})/;

    const pass = document.querySelector('#pass');
    const span = document.querySelector('#passSpan');
    if(!lowRegex.test(String(pass.value))){
        pass.classList.add('uncorrect');
        span.textContent = "manca il carattere minuscolo";
        update = false;
    }
    else if(!uppRegex.test(String(pass.value))){
        pass.classList.add('uncorrect');
        span.textContent = "manca il carattere maiuscolo";
        update = false;
    }
    else if(!numRegex.test(String(pass.value))){
        pass.classList.add('uncorrect');
        span.textContent = "manca il numero";
        update = false;
    }
    else if(!specialRegex.test(String(pass.value))){
        pass.classList.add('uncorrect');
        span.textContent = "manca il carattere speciale";
        update = false;
    }
    else if(!sizeRegex.test(String(pass.value))){
        pass.classList.add('uncorrect');
        span.textContent = "la password deve avere almeno 8 caratteri";
        update = false;
    }
    else{
        pass.classList.remove('uncorrect');
        span.textContent = "";
        update = true;
    }*/
    enableSubmit();
}

var update = false;
document.querySelector('#email').addEventListener('blur', validateEmail);
document.querySelector('#username').addEventListener('blur', validateUsername);
document.querySelector('#pass').addEventListener('blur', validatePass);