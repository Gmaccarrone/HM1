<?php
    require_once 'checkSession.php';
    if (!$id = checkSession()) {
        header("Location: login.php");
        exit;
    }
    else{
        $codice = $_SESSION['id'];
        $conn = mysqli_connect("localhost","root","","tvblogdb");
    }
    $post = array();
    for($i = 0; $i<9; $i++){
        if($_POST["status$i"] == "selected"){
            $status = 1;
        }
        else $status = 0;
       array_push($post,$status);
    }
    // ordina la  lista del metodo post $post[3]['genere']

    $checkQuery = "SELECT * FROM generi where utente = $codice;";
    //controlla se esiste una lista di generi 
    $checkRes = mysqli_query($conn, $checkQuery) or die(mysqli_error($conn));
    $checkRow = mysqli_fetch_assoc($checkRes);
    if($checkRow){
        $upQuery = "update generi set commedia = $post[0], drammatico = $post[1], horror = $post[2], 
                    romantico = $post[3], azione = $post[4], avventura = $post[5], retro = $post[6], 
                    fantasy = $post[7], bambini = $post[8] where utente = $codice;";
        $upRes = mysqli_query($conn, $upQuery) or die(mysqli_error($conn));
        $json = "OK_UPDATED";
    }
    else{
        $insertQuery = "INSERT into generi values($codice,$post[0],$post[1],$post[2],$post[3],
                                                 $post[4],$post[5],$post[6],$post[7],$post[8])";
        
        $insertRes = mysqli_query($conn, $insertQuery) or die(mysqli_error($conn));
        $json = "OK_INSERTED";
    }

    echo json_encode($json);
?>