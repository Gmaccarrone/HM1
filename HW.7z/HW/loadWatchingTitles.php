<?php 
    require_once 'checkSession.php';
    if (!$id = checkSession()) {
        header("Location: login.php");
        exit;
    }
    else{
        $codice = $_SESSION['id'];
        $username = $_SESSION['username'];
        $conn = mysqli_connect("localhost","root","","tvblogdb");
    }
    $i = 0;
    $query = "SELECT t.nome , t.codice from visione v join titolo t on v.TITOLO = t.codice where v.utente = $codice and v.guardando = true";
    $res = mysqli_query($conn, $query) or die(mysqli_error($conn));
    
    $returndata = array('status' => 'ok', 'titles' => array(),'codes' => array());
    while($wRow = mysqli_fetch_assoc($res)){

        $returndata['titles'][$i]=$wRow['nome'];
        $returndata['codes'][$i]=$wRow['codice'];
        
        $i++;
    }
    echo json_encode($returndata);
?>