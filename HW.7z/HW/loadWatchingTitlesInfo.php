<?php 
require_once 'checkSession.php';
    if (!$id = checkSession()) {
        header("Location: login.php");
        exit;
    }
    else{
        $codice = $_SESSION['id'];
        $conn = mysqli_connect("localhost","root","","tvblogdb");
    }
    //recupera dati post
    $titleID = $_POST['titleID'];

    $query = "select * from viewsdata v join titdata t on t.codice = v.titolo where v.utente = $codice and t.codice = $titleID;";
    $res = mysqli_query($conn, $query) or die(mysqli_error($conn));
    if($res){
        $wRow = mysqli_fetch_assoc($res);
        $uploaderID = $wRow['uploader'];
        $picQuery = "select propic from utente where codice = $uploaderID;";
        $picRes = mysqli_query($conn, $picQuery) or die(mysqli_error($conn));
        $picRow = mysqli_fetch_assoc($picRes);

    $json = array  ('nome' => $wRow['nome'],
                    'database' =>$wRow['db'],
                    'uploader' =>$wRow['uploader'],
                    'globalRate' => $wRow['punteggio'],
                    'views' => $wRow['vievs'],
                    'watchingnow' => $wRow['watching'],
                    'yourVote' => $wRow['voto'],
                    'yourViews' => $wRow['visto'],
                    'comment' => $wRow['commento'],
                    'propic' => 'data:image1/jpeg;base64,'.base64_encode($picRow['propic'])
                    );

    echo json_encode($json);
    } else echo json_encode(null);
?>