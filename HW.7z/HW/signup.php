<?php
    $conn = mysqli_connect('localhost','root','','tvblogdb') or die(mysqli_error($conn));
    $error = '';
    
    if (!empty($_POST["email"]) && !empty($_POST['email']) ){
        
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $eMail = mysqli_real_escape_string($conn, $_POST['email']);
        $date = mysqli_real_escape_string($conn, $_POST['date']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);
        $password = password_hash($password, PASSWORD_BCRYPT);
        $propic = addslashes(file_get_contents($_FILES["propic"]["tmp_name"]));


    //controlla che il nome non sia utilizzato
        $username_query = "SELECT username FROM utente WHERE username LIKE '$username';";
        $username_res = mysqli_query($conn, $username_query) or die(mysqli_error($conn));
        if(mysqli_num_rows($username_res)===1){
            $error = 'username già in uso'; 
        }
        else {
            $error = ''; 
             //controlla che la mail non sia utilizzata
            $eMail_query = "SELECT email FROM utente WHERE email LIKE '$eMail';";
            $eMail_res = mysqli_query($conn, $eMail_query) or die(mysqli_error($conn));
            if(mysqli_num_rows($eMail_res)>0){
                $error = 'eMail già in uso'; 
            }
            else {
                $error = '';
                $query = "INSERT INTO utente VALUES(0,'$username','$date','$eMail','$password','$propic');";
                $res = mysqli_query($conn, $query) or die(mysqli_error($conn));
            }
        }

        
    }

?>

<html>
    <head>
    <link rel='stylesheet' href='./style/formsStyle.css'>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">

    <script src='./scripts/checkSignupScript.js' defer></script>

    <link rel="shortcut icon" type="image/png" href="favicon.png">
    <title>TVBlog - Signup</title>
    </head>
    <body>
        <main>
            <section id = 'welcomePhoto'>
            </section>
            <section id = 'signupForm'>

                <h1>Iscriviti ora!
                    <?php
                        echo"<span class = 'mainSpan'>$error</span>";
                    ?>
                </h1>
                <form name='signup' method='post' enctype="multipart/form-data" autocomplete="off">
                    
                <div><label for='username'>Username</label></div>
                    <div><input type='text' name='username' id = 'username'></div>
                    <div><span id = 'usernameSpan'></span></div>

                    <div><label for='email'>eMail</label></div>
                    <div><input type='email' name='email' id='email'></div>
                    <div><span id = 'emailSpan'></span></div>
                    
                    <div><label for='password'>Password</label></div>
                    <div><input type='password' name='password' id = 'pass'></div>
                    <div><span id = 'passSpan'></span></div>

                    <div><label for='c_password'>Conferma password</label></div>
                    <div><input type='password' name='c_password' id = 'cPass'></div>
                    <div><span id = 'cPassSpan'></span></div>
                    
                    <div><label for='date'>Data di nascita</label></div>
                    <div><input type='date' name='date' id = 'date'></div>
                    <div><span id = 'dateSpan'></span></div>
                    
                    <div><label for='propic'>Immagine del profilo</label></div>
                    <div><input type='file' name='propic' accept='.jpg, .jpeg, image/gif, image/png' id="propic"></div>
                    <div id='fakeInputFile'>scegli un file</div>
                    <div><span id = 'propicSpan'></span></div>

                    <div>
                    <label>&nbsp;<input type='submit' name='submit' id = 'submit' ></label>
                    </div>
                    <div id ="toLogin">Hai già un account? <a href="login.php">Accedi</a></div>
                </form>
            </section>
        </main>
    </body>    
</html>