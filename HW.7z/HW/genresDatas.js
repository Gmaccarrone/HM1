console.log('file on');
const DATA_LIST = [
    {
    img : './images/commedia.jpg',
    titolo: 'Commedia',
    desc: 'con questi film le risate sono assicurate!',
    status: 'unselected'
    },//commedia
    
    {img:'./images/drama.jpg', 
     titolo: 'Drammatico',
     desc: 'L\'ideale per piangere in compagnia',
     status: 'unselected'
    },//drammatico

    {img: './images/horror.jpg', 
    titolo: 'Horror',
    desc: 'Non prendertela con noi se poi hai gli incubi',
    status: 'unselected'
    },//horror
        
    {img: './images/romantic.jpg', 
    titolo: 'Romantico',
    desc: 'Le migliori storie d\'amore di sempre',
    status: 'unselected'
    },//romantico
    
    {img: './images/boom.jpeg', 
    titolo: 'Azione',
    desc: 'Adrenalina a mille e sparatorie al cardiopalma',
    status: 'unselected'
    },//azione
    
    {img: './images/Indiana.jpg', 
    titolo: 'Avventura',
    desc: 'Film dedicati a viaggi intensi e misteriose scoperte',
    status: 'unselected'
    },//avventura
    
    {img: './images/vintage.jpg', 
    titolo: 'Retrò',
    desc: 'Per i VERI appassionati di film d\'epoca',
    status: 'unselected'
    },//retrò
    
    {img: './images/Gandalf.jpg', 
    titolo: 'Fantasy',
    desc: 'Scopri nuovi e meravigliosi mondi',
    status: 'unselected'
    },//fantasy
    
    {img: './images/teletubbies.jpg', 
    titolo: 'Bambini',
    desc: 'Niente ansie per voi genitori! questi film sono a prova di bambini',
    status: 'unselected'
    }//bambini
];


