<?php
require_once 'checkSession.php';
if (!$id = checkSession()) {
    header("Location: login.php");
    exit;
}
else{
    $codice = $_SESSION['id'];
    $conn = mysqli_connect("localhost","root","","tvblogdb");
}
//recupera dati post
$title = $_POST['titleName'];

$query = "select * from titdata where nome like '$title%'";
$res = mysqli_query($conn, $query) or die(mysqli_error($conn));
if($res){
    $wRow = mysqli_fetch_assoc($res);
    $uploaderID = $wRow['uploader'];
    $picQuery = "select propic from utente where codice = $uploaderID;";
    $picRes = mysqli_query($conn, $picQuery) or die(mysqli_error($conn));
    $picRow = mysqli_fetch_assoc($picRes);
    $titleID = $wRow['codice'];
    $vQuery = "select * from visione where utente = $codice and titolo = '$titleID';";
    $vRes = mysqli_query($conn, $vQuery) or die(mysqli_error($conn));
    $vRow = mysqli_fetch_assoc($vRes);

$json = array  ('codice' => $titleID,
                'nome' => $wRow['nome'],
                'database' =>$wRow['db'],
                'uploader' =>$wRow['uploader'],
                'globalRate' => $wRow['punteggio'],
                'views' => $wRow['vievs'],
                'watchingnow' => $wRow['watching'],
                'propic' => 'data:image1/jpeg;base64,'.base64_encode($picRow['propic']),
                'visto' => $vRow['n_visto'] 
                );

echo json_encode($json);
} else echo json_encode(null);
?>