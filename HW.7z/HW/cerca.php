<?php
    require_once 'checkSession.php';
    if (!$id = checkSession()) {
        header("Location: login.php");
        exit;
    }
?>

<head>
    <title>Tv Blog - CercaTitoli</title>
    <meta name="viewport" content="width=device-width, initial-scale1">
    <meta charset="utf-8">

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">

    <link href="./style/cerca.css" rel = "stylesheet">

    <script src='./scripts/logout.js' defer></script>
    <script src="./scripts/cercaScript.js" defer></script>
</head>
<body>
    <div id = 'modalov' class='hidden'>
        <div id = 'lastWarningLogout' class='hidden'>
            <div>Sicuro di voler eseguire il logout?</div>
            <div id="logoutMenu">
                <a class="link" id="abort">annulla</a>
                <a class="link" href="logout.php" id="cLogout">logout</a>
            </div>
        </div>
    </div>
   
    <header>
        <div id="top">
            <img src="./images/tvblogo.png" id = 'logo'>
            <nav>
                <a class="link" href="home.php" id="home">Home</a>
                <a class="link" href="cerca.php" id="cerca">Cerca</a>
                <a class="link" href="generi.php" id="generi">Generi</a>
                <a class="link" href="visto.php" id="visto">Visto</a>
                <a class="link" id="logout">logout</a>
            </nav>
            <nav id = "box-menu">
                <h3 id="menu-line"> </h3>
                <h3 id="menu-line"> </h3>
                <h3 id="menu-line"> </h3>
            </nav>
        </div>
    </header>

    <form id="searchBar">
        <input placeholder="Cerca un titolo" id="query" autocomplete="off">
        <input type="image" id="searchButton" alt="Submit" src="https://www.materialui.co/materialIcons/action/search_white_192x192.png">
    </form>

    <div id="waitingDiv">
        <label class="waitingTitle">Trova informazioni sui titoli che ti interessano</label>
        <img id="waitingImg" src="./images/Ud8xgso.gif">    
        <label class="waitingTitle">Aspettiamo solo che tu cerchi qualcosa</label>
    </div>

    <section id="IMDBBox" class="hidden">
        <div id="IMDBTitleBox">
            <h1 id="IMDBTitle" class="hidden">Cosa troviamo cercando su </h1>
            <img src="./images/imdbLogo.png"  id="IMDBLogo" class="hidden"> 
            <img src="./images/addToDB.png" id="IMDBAddButton">
        </div>

        <div id="IMDBResult">
            <img id="IMDBPoster" class="hidden">
            <div id="IMDBDetails" class="hidden">
                <h1 id="IMDBResultTitle"></h1><br>
            <div id ="IMDBSecondaryInfo">
                <div id="IMDBInfo">
                    <h1 id="IMDBType"></h1>
                    <h1 id="IMDBGenres"></h1>
                    <h1 id="IMDBdate"></h1>
                </div>
                <div id="IMDBRating">
                    <h1 id="IMDBRateTxt" class="hidden">Voto:</h1>
                    <h1 id="IMDBRate" class="hidden"></h1>
                </div>
            </div>
                <h1 id="IMDBPlot"></h1>
            </div>
        </div>
    </section> 

    <section id = 'TVBResult' class = 'hidden'>
        <div id = mainTVBinfo class = 'hidden'>
            <div id = 'mainTitle'>
                <h1>nel database di</h1><img src = './images/tvblogo.png' id = "TVBDBLogo"><h1>troviamo</h1>
            </div>
            <h1 class = 'TvbName'></h1>
            <div id = 'buttonBar'>
                <img src="./images/guardando.png" id = "wButton">
                <div id = "vMenu">
                    <img src="./images/dec.png" id = "decButton">
                    <h1 id = "saw"></h1>
                    <img src="./images/inc.png" id = "incButton">
                </div>
            </div>
        </div>
        <div id = 'TVBMainData' class = 'hidden'>            
            <div class = 'TVBdata'>
                <h1 id = 'TvbRate'>Voto: </h1>
                <h1 id = 'TvbRateData' class = "result"></h1>
            </div>
            <div class = 'TVBdata'>
                <h1 id = 'Tvbviews'>visualizzazioni: </h1>
                <h1 id = 'TvbviewsData' class = "result"></h1>
            </div>
            <div class = 'TVBdata'>
                <h1 id = 'TvbWatching'>stanno guardando: </h1>
                <h1 id = 'TvbWatchingData' class = "result"></h1>
            </div>
            <div id = 'DB'>
                <h1>database: </h1>
                <img src = "favicon.png" id = 'DBimg' class = "result">
            </div>
            <div id = 'uploader'>
                <h1>uploader: </h1>
                <img src = "favicon.png" id = 'UPimg' class = "result">
            </div>
        </div>
    </section>

    <footer>
        <txt-footer>Powered by Giuseppe Maccarrone - O46001814</txt-footer><br>
        <txt-footer id="uni">Università degli studi di catania - corso di web programming</txt-footer>
    </footer>
</body>