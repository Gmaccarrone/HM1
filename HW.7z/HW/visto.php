<?php
    require_once 'checkSession.php';
    if (!$id = checkSession()) {
        header("Location: login.php");
        exit;
    }
?>

<head>
    <title>TVBlog - visto</title>
    <meta name="viewport" content="width=device-width, initial-scale1">
    <meta charset="utf-8">
    <script src='./scripts/vistoScript.js' defer></script>
    <script src='./scripts/logout.js' defer></script>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">

    <link href="./style/vistoStyle.css" rel = "stylesheet">
    <link rel="shortcut icon" type="image/png" href="favicon.png">
    
</head>
<body>
            <!--mosta le info sui titoli-->

    <div id = 'modalov' class='hidden'>
        <div id = 'lastWarningLogout' class='hidden'>
            <div>Sicuro di voler eseguire il logout?</div>
            <div id="logoutMenu">
                <a class="link" id="abort">annulla</a>
                <a class="link" href="logout.php" id="cLogout">logout</a>
            </div>
        </div>
    </div>

    <div id = 'modalovTitle' class = 'hidden'>
        <div id = 'TitleInfo' class = 'hidden'>
            <div id = socialBar>
                <div id = "starMenu">
                    <img src="./images/emtyStar.png" id="s1" class="star">
                    <img src="./images/emtyStar.png" id="s2" class="star">
                    <img src="./images/emtyStar.png" id="s3" class="star">
                    <img src="./images/emtyStar.png" id="s4" class="star">
                    <img src="./images/emtyStar.png" id="s5" class="star">
                </div>
                <div id = "vMenu">
                    <img src="./images/dec.png" id = "decButton" class = 'socialButton'>
                    <h1 id = "saw"></h1>
                    <img src="./images/inc.png" id = "incButton" class = 'socialButton'>
                </div>

                <img src="./images/comment.png" class="socialButton" id="writeComment">

                <img src="./images/back.png" class="socialButton" id="abortTitle"> 
            </div>
            <div class="titleName"></div>
            <div id = 'comment' class ='hidden'>
                <textarea id = "commentArea" class ='hidden' placeholder='Scrivi un commento . . .'></textarea>
                <div id = 'submit' class ='hidden'>Invia</div>
            </div>
            <div id = 'commentsGrid'>

            </div>
        </div>
    </div>

    <header>
            <div id="top">
                <img src="./images/tvblogo.png" id = 'logo'>
                <nav>
                    <a class="link" href="home.php" id="home">Home</a>
                    <a class="link" href="cerca.php" id="cerca">Cerca</a>
                    <a class="link" href="generi.php" id="generi">Generi</a>
                    <a class="link" href="visto.php" id="visto">Visto</a>
                    <a class="link" id="logout">logout</a>
                </nav>
                <nav id = "box-menu">
                    <h3 id="menu-line"> </h3>
                    <h3 id="menu-line"> </h3>
                    <h3 id="menu-line"> </h3>
                </nav>
            </div>
        </div>
    </header>

    <div id = 'resultGrid'>
        <!--qui vanno aggiunti tutti i film visti-->
    </div>

    <footer>
        <txt-footer>Powered by Giuseppe Maccarrone - O46001814</txt-footer><br>
        <txt-footer id="uni">Università degli studi di catania - corso di web programming</txt-footer>
    </footer>
</body>