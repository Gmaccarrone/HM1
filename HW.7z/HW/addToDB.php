<?php
    require_once 'checkSession.php';
    if (!$id = checkSession()) {
        header("Location: login.php");
        exit;
    }
    else{
        $codice = $_SESSION['id'];
        $conn = mysqli_connect("localhost","root","","tvblogdb");
    }
    $titlename = $_POST['titleName'];
    $type = $_POST['type'];
    $db = $_POST['db'];
    $insertQuery = "INSERT into titolo values('0', '$titlename', '$type', '$db', '$codice');";
    $res = mysqli_query($conn, $insertQuery); 
    $err = mysqli_error($conn);
    
    if(!$err){
        $json = "OK_INSERTED";
        echo json_encode($json);
    }
    else if($err == "Duplicate entry 'up' for key 'nome'"){
        $json = "ALREDY_IN_DB";
        echo json_encode($json);
    }
    else {
        $json = $err;
        echo json_encode($json);
    }
?>