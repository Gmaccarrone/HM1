<?php
    require_once 'checkSession.php';
    if (!$id = checkSession()) {
        header("Location: login.php");
    exit;
    }
    else{
        $codice = $_SESSION['id'];
        $conn = mysqli_connect("localhost","root","","tvblogdb");
    }
    $i = 0;
    $query = "SELECT t.codice as codice, t.nome as nome FROM titolo t join visione v on t.codice = v.titolo where v.utente = $codice and v.n_visto > 0";
    $res = mysqli_query($conn,$query) or die(mysqli_error($conn));
    
    $returndata = array('status' => 'ok', 'titles' => array(),'codes' => array());
    while($row = mysqli_fetch_assoc($res)){

        $returndata['titles'][$i]=$row['nome'];
        $returndata['codes'][$i]=$row['codice'];
        
        $i++;
    }
    echo json_encode($returndata);
?>