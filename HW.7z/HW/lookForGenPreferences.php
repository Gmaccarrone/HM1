<?php
    require_once 'checkSession.php';
    if (!$id = checkSession()) {
        header("Location: login.php");
        exit;
    }
    else{
        $codice = $_SESSION['id'];
        $conn = mysqli_connect("localhost","root","","tvblogdb");
    }
    $notF = "NOT_FOUND";
    $query = "SELECT * FROM generi where utente = $codice;";
    $res = mysqli_query($conn, $query) or die(mysqli_error($conn));
    $row = mysqli_fetch_assoc($res);
    if($row){
        $json = array(0 => array('genere'=> 'commedia', 'status' => $row['commedia']),
        1 => array('genere'=> 'drammatico', 'status' => $row['drammatico']),
        2 => array('genere'=> 'horror', 'status' => $row['horror']),
        3 => array('genere'=> 'romantico', 'status' => $row['romantico']),
        4 => array('genere'=> 'azione', 'status' => $row['azione']),
        5 => array('genere'=> 'avventura', 'status' => $row['avventura']),
        6 => array('genere'=> 'retro', 'status' => $row['retro']),
        7 => array('genere'=> 'fantasy', 'status' => $row['fantasy']),
        8 => array('genere'=> 'bambini', 'status' => $row['bambini'])
        );
        echo json_encode($json);
    }
    else{ 
        echo json_encode($notF);
    }
?>