<?php

session_start();//comincia la sessione o riprende quella esistenete

    function checkSession() { // controlla che la sessione delle credenziali
        if(isset($_SESSION['id'])) {
            return $_SESSION['id']; //se si torna il codice utente
        } else {     
    return 0;
    }
}

?>