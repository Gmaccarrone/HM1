<?php
    require_once 'checkSession.php';
    if (!$id = checkSession()) {
        header("Location: login.php");
        exit;
    }
    else{
        $codice = $_SESSION['id'];
        $username = $_SESSION['username']; //prendo l'username dalla sessione
        $conn = mysqli_connect("localhost","root","","tvblogdb"); //faccio una query per avere l'immagine
        $query = "SELECT propic FROM utente WHERE codice like $id";
        $res = mysqli_query($conn, $query) or die(mysqli_error($conn)); 
        $result=mysqli_fetch_array($res);
        $src = 'data:image/jpeg;base64,'.base64_encode( $result['propic'] );
        
    }
?>
<head>
    <title>TVBlog - Home</title>
    <meta name="viewport" content="width=device-width, initial-scale1">
    <meta charset="utf-8">
    <script src='./scripts/homeScript.js' defer></script>
    <script src='./scripts/logout.js' defer></script>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">

    <link href="./style/homeStyle.css" rel = "stylesheet">
    <link rel="shortcut icon" type="image/png" href="favicon.png">
    
</head>
<body>
            <!--mosta le info sui titoli-->
    <div id = 'modalovTitle' class='hidden'>
        <div id = 'TitleInfo' class='hidden'>
            
            <div id="backDiv">
                <img src="./images/back.png" class="tButton" id="abortTitle"> 
            </div>
            <div class="titleName"></div>
            <div id="stats">
                <div id = 'viewsBox' class='statBox'>
                    <div id='viewsName'>Visto</div>
                    <div id='views'></div>
                    <div id='viewsName'>volte</div>
                </div>
                <div id = 'rateBox' class='statBox'>
                    <div id='rateName'>Voto:</div>
                    <div id='rate'></div>
                </div>
                <div id = 'watchingBox' class='statBox'>
                    <div id='watchingName'>stanno guardando:</div>
                    <div id='watching'></div>
                </div>                
            </div>
            <div id="TitleMenu">
                <img src="./images/visto.png" class="tButton" id="completeTitle">
                <div id = "starMenu">
                    <img src="./images/emtyStar.png" id="s1" class="star">
                    <img src="./images/emtyStar.png" id="s2" class="star">
                    <img src="./images/emtyStar.png" id="s3" class="star">
                    <img src="./images/emtyStar.png" id="s4" class="star">
                    <img src="./images/emtyStar.png" id="s5" class="star">
                </div>
                <img src="./images/comment.png" class="tButton" id="writeComment">
                <div id = 'uploader'>uploader <img src='favicon.png' id = "uploaderPropic"></div>  
                <div id = 'DB'>From <img src='favicon.png' id='DBpic'></div>     
            </div>
            <div id = 'comment' class ='hidden'>
                <textarea id = "commentArea" class ='hidden' placeholder='Scrivi un commento . . .'></textarea>
                <div id = 'submit' class ='hidden'>Invia</div>
            </div>
        </div>
        <!--/////////////////// INFO TOP 3 ///////////////////-->
        <div id = 'T3TitleInfo' class='hidden'>
            <div id="backDiv">
                <img src="./images/back.png" class="tButton" id="abortTitle"> 
            </div>
            <div class="T3titleName"></div>
            <div id="stats">
                <div id = 'T3viewsBox' class='statBox'>
                    <div id='viewsName'>Visto</div>
                    <div id='T3views'></div>
                    <div id='viewsName'>volte</div>
                </div>
                <div id = 'T3rateBox' class='statBox'>
                    <div id='rateName'>Voto:</div>
                    <div id='T3rate'></div>
                </div>
                <div id = 'T3watchingBox' class='statBox'>
                    <div id='watchingName'>stanno guardando:</div>
                    <div id='T3watching'></div>
                </div>
            </div>
            <div id="TitleMenu">
                <img src="./images/guardando.png" class="tButton" id="startWTitle">
                <img src="./images/visto.png" class="tButton" id="sawTitle">
                <div id ="timesSaw"> </div>
                <div id = 'uploader'>uploader <img src='favicon.png' id = "T3uploaderPropic"></div>  
                <div id = 'DB'>From <img src='favicon.png' id='DBpic'></div>                     
            </div>
        </div>
    </div>

    <div id = 'modalov' class='hidden'>
        <div id = 'lastWarningLogout' class='hidden'>
            <div>Sicuro di voler eseguire il logout?</div>
            <div id="logoutMenu">
                <a class="link" id="abort">annulla</a>
                <a class="link" href="logout.php" id="cLogout">logout</a>
            </div>
        </div>
    </div>

    <header>
            <div id="top">
                <img src="./images/tvblogo.png" id = 'logo'>
                <nav>
                    <a class="link" href="home.php" id="home">Home</a>
                    <a class="link" href="cerca.php" id="cerca">Cerca</a>
                    <a class="link" href="generi.php" id="generi">Generi</a>
                    <a class="link" href="visto.php" id="visto">Visto</a>
                    <a class="link" id="logout">logout</a>
                </nav>
                <nav id = "box-menu">
                    <h3 id="menu-line"> </h3>
                    <h3 id="menu-line"> </h3>
                    <h3 id="menu-line"> </h3>
                </nav>
            </div>
        </div>
    </header>
    
    <div id ='profile'>
        <img src=<?php echo"$src";?> id = "propic">
        <h1>Bentornato <?php echo"$username";?>!</h1>
    </div>

    <div>
        <div id='results-container'>
            <h2 id='watching-title'>Ecco cosa stavi guardando</h2>
            <div id='results-grid'>
                <!-- qui inseriamo gli elementi del nostro DB tramite API -->
            </div>
        </div>
    
        <div id='top-3-container'>
            <h2 id='top-3-title'>Top 3 contenuti visti secondo il nostro DataBase</h2>
            <div id='results-grid'>
                <div id='t1' class = 't3Button'>
                    <h4>1#</h4>
                </div>
                <div id='t2' class = 't3Button'>
                    <h4>2#</h4>
                </div>
                <div id='t3' class = 't3Button'>
                    <h4>3#</h4>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <txt-footer>Powered by Giuseppe Maccarrone - O46001814</txt-footer><br>
        <txt-footer id="uni">Università degli studi di catania - corso di web programming</txt-footer>
    </footer>
</body>